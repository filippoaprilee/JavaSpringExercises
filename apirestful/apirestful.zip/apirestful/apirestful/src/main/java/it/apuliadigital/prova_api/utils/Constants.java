package it.apuliadigital.prova_api.utils;

public class Constants {
    public static final String JSON_FILE_PATH = "persone.json";
}
