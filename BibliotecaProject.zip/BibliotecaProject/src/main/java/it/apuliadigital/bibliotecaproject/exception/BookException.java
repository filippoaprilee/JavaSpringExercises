package it.apuliadigital.bibliotecaproject.exception;

public class BookException extends RuntimeException{

    public BookException(String message) {
        super(message);
    }
}