package it.apuliadigital.bibliotecaproject.service;

public interface LogService {
    void saveLog(String path, String message);
}