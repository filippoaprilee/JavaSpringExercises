package it.apuliadigital.bibliotecaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecaProjectApplication.class, args);
	}

}
