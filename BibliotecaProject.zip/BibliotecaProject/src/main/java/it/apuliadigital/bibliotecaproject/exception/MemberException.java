package it.apuliadigital.bibliotecaproject.exception;

public class MemberException extends RuntimeException {

    public MemberException(String message) {
        super(message);
    }
}
